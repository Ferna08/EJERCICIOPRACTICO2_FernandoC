package EjerPrac2_Fernando.CineTeatro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CineTeatroApplicationTests {

	@Test
	void contextLoads() {
	}

}
